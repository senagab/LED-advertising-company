<!-- FOOTER -->

<footer class="footer">
    <div class="footer-container">
        <span class="footer-email">
            toni@myled.com.br
        </span>
        <span class="footer-copyright">
            © <span class="text-bold">My Led</span> 2025 All Rights Reserved.
        </span>
        <div class="footer-socials">
            <a href="#">
                <img class="social-item" src="./assets/images/footer/instagram.png" alt="">
            </a>
            <a href="#">
                <img class="social-item" src="./assets/images/footer/whatsapp.png" alt="">
            </a>
            <a href="#">
                <img class="social-item" src="./assets/images/footer/facebook.png" alt="">
            </a>
        </div>
    </div>
</footer>

<!-- FIM FOOTER -->