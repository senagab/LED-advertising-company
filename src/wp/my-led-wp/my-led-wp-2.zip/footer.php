
<!-- FOOTER -->

<footer class="footer">
    <div class="footer-container">
        <span class="footer-item">
            <img src="./assets/images/footer/whatsapp.png" alt="">
            Fale Conosco
        </span>
        <span class="footer-logo">
            <img src="./assets/images/footer/footer-logo.png" alt="">
        </span>
        <span class="footer-item">
            Cadastre-se!
            <img src="./assets/images/footer/sign-up.png" alt="">
        </span>
    </div>
</footer>

    <script src="./src/main.js"></script>
    <?php wp_footer(); ?>

</body>
</html>

<!-- FIM FOOTER -->